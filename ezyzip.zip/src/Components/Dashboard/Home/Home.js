
//import {} from "@mui/material"
import { HomeOffer } from "./HomeOffer"
import { HomeBody } from "./HomeBody"

export const Home=()=>{
    return (
        <div>

          <HomeOffer></HomeOffer>
          <HomeBody></HomeBody>

      
        </div>
    )
}