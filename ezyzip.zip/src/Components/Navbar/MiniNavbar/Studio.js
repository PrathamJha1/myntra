export const StudioNav=()=>{


    return(
        <div
        className="ddown"
        style={{
          marginLeft: "-250px",
          width: "520px"
          
        }}
        >
            <div  className="studioImg">
                <img src="https://constant.myntassets.com/web/assets/img/studio-logo-new.svg" alt="" />
                <p>Your daily inspiration for everything fashion</p>
            </div>
            
         <div>
             <img    style={{
          width: "500px",
          
        }} src="https://constant.myntassets.com/web/assets/img/sudio-nav-banner.png" alt="" />
         </div>
         <div className="explore_studio">
             <button>
             EXPLORE STUDIO
             </button>
         </div>
    
        </div>
    )
    
    
    }