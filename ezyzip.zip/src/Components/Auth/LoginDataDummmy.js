const AuthData = [
    {
        email:"abc@gmail.com",
        password:"abc"
    }
]
export default AuthData;